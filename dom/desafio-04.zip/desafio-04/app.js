new Vue({
	el: '#desafio',
	data: {

	},
	methods: {
		iniciarEfeito() {

		},
		iniciarProgresso() {

		}
	}
})
